#-*-coding: UTF-8-*-
print("vamos calcular seu juros?")
P= int(input("digite o capital inicial:"))
i=float(input("digite taxa de juros: "))
t=int(input("digite a quantidade de meses:"))

i=P*i*t


          
print("i: ",P*i*t)

