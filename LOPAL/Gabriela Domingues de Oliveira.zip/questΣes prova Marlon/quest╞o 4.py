print("quer  ver como esta o clima hoje?")
temp = int(input("digite a temperaura de hoje:"))

if temp == <15:
    print("o clima está frio")
    
    elif temp == >14 and <26:
        print("clima está agradavel")
        
        else:
            print("o clima está quente")
        
