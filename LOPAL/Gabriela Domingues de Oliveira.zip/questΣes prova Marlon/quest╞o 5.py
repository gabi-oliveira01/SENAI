print("vamos calcular  o desconto que você ganhara?")
pc  = int(input("digite o valor gasto em produtos na loja:"))
ts= int(input("digite seu tempo de serviço em anos:"))

if ts== 10 anos or 5 anos:
    desconto = pc*0.05
        print("desconto: ",pc*0.05)
    valor total= pc - desconto
        print("valor total: ",  pc - desconto)
    
    elif ts== >10 anos:
    desconto = pc*0.1
        print("desconto: " , pc*0.1)
    valor total = pc - desconto
        print("valor total: ",pc - desconto)

else:
    print("você não tem direito a desconto ainda")


    
    
