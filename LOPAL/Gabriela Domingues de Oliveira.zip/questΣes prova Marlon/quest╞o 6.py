fim = int(input("Digite o último número a imprimir: "))
x = 1
soma = x + fim
while x <= fim:
    print(x)
    x = x + 1
x = int(input("%x " % x))
soma = soma + x
x = x + 1
print ("Soma: %x" % soma)
    

