print( "vamos calcular o volume de uma piramide")
area = int(input("digite a area: "))
altura= int(input("digite a altura:"))

v = (1/3) * area * altura

print("volume: ", (1/3) * area * altura)
