#-*-coding: UTF-8-*-
for i in range (10):
    print(f"Tabuada de {i}:")
    for a in range(1,11):
        print(f"{i} x {a} = {i * a}")
