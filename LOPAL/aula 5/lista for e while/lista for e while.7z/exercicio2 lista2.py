#-*-coding: UTF-8-*-

print("ola,vamos fazer a soma  dos primeiros 50 numeros pares")
n = 0
for i in range (0,101,2):
    n = n + i
print("a soma dos primeiros 50 numeros é" , n)
