#-*-coding: UTF-8-*-

while True:
    V= int(input("digite um número,porém quando se encerra em -999:"))
    if V == -999:
        print("voce encerrou,tchau")
        break
    triplo = V * 3
    print(triplo)



