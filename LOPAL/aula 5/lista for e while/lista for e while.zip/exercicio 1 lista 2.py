#-*-coding: UTF-8-*-
# Programa para imprimir todos os numeros de 1 a 50

for V in range(1,51,1) :
    print(V)
for V in range (50,0,-1) :
    print(V)

