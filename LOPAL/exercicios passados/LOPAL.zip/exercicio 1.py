#-*-codng: UTF-8*-
print("digite dois valores inteiros")
num1=int(input("digite o primeiro numero inteiro:"))
num2=int(input("digite o segundo valor inteiro:"))
soma= num1+num2
print("o resultado da soma dos numeros inteiros é:" , soma)
