print("digite o salario do funcionario e calcule o valor do aumento")
salarios= int(input("digite seu salario"))
porcent=salarios + 10 / 100
if salario > 1.250:
    print(" seu salario teve aumento de(porcent)")
elif salario <= 1.250:
 porcent2 = (salario * 15 /100)
print(f"seu salario tem aumento de (porcent 2 !")
