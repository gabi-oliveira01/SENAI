#-*-coding:UTF-8-*-
print("digite seus dias,horas e minutos e eu transformarei em segundos trabalhados")
tempo1=float(input("escreva suas horas:"))
tempo2=float(input("escreva seus minutos:"))
tempo3=float(input("escreva seus dias:"))
tempo4=float(input("escreva os segundos:"))
ts=(tempo1*3600) + (tempo2*86400)+(tempo3*60) +(tempo4)
print("o tempo trabalhado por segundo sao:" ,ts)
