#-*-coding:UTF-8-*-
print("digite seu salario e o aumento que deseja")
salario=float(input("digite seu salario:"))
aumento=float(input("digite a porcentagem desejada:"))
porcentagem=salario*aumento/100
print("o seu aumento será:" ,porcentagem)
