#-*-coding:UTF-8-*-
print("qual o valor do produto e seu desconto")
produto=float(input("digite o valor do produto:"))
desconto =float(input("digite o valor do desconto:"))
subtraçao=produto-desconto
print("o seu produto e o desconto será:" ,subtraçao)
