print("vamos converter a temperatura de Celsius para Fahrenheit")
celcius: float(input("digite a temperatura em Celsius: " ))
fah = 9 / 5 * Celsius + 32
print (" a temperatura convertida foi de:" , Fah)

