#-*-coding: UTF-8-*-
print("digite o valor em metros e o converta em milimetros")
valor1=int(input("digite o valor em milimetros:"))
valor2=valor1*1000
print("o resultado da multiplicao é: ", valor2)


           
