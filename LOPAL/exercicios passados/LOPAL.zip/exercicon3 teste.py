Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========== RESTART: C:/Users/2anoA/Documents/SENAI/LOPAL/exercicio2.py =========
digite o valor em metros e o converta em milimetros
digite o valor em milimetros:20
o resultado da multiplicao é:  20000
>>> 
========= RESTART: C:/Users/2anoA/Documents/SENAI/LOPAL/exercicio 3.py =========
digite seus dias,horas e minutos e eu transformarei em segundos trabalhados
escreva suas horas:4
escreva seus minutos:9
escreva seus dias:7
escreva os segundos:8
o tempo trabalhado por segundo sao: 792428.0
