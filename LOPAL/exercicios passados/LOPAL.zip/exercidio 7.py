print("vamos calcular o tempo de viagem")
ditancia= float(input("digite a distancia percorrida:"))
veloci_media=float(input("digite a velocidade media:"))
tempo= distancia / veloci_media
print(" o tempo de vaigem foi de:")


