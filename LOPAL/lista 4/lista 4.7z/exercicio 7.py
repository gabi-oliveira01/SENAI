#-*-coding: UTF-8-*-
print(" digite dois valores e eu farei um calculo de acordo com o operador desejado")
num1= float(input("digite o numero:"))
num2= float(input("digite o  segundo numero:"))
operador= str(inpt("escolha  a operação que ira usar "+","-","*", "/" os sinais de cada operação"))

def calculo (num1,num2):
    resultado =0
    if operação = "+":
       resultado = num1+num2

       print(resultado)
    elif operação == "-":
        resultado=num1-num2
        print(resultado)
    elif operação == "*":
        resultado=num1*num2
        print(resultado)
    elif operação == "/":
        resultado = num1/num2
        print(resultado)
    
    
    
    
