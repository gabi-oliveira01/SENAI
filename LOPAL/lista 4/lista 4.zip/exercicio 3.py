#-*-coding: UTF-8-*-
print("me de um numero de 1 a 10 e mostrarei a tabuada dele")
numero = int(input("digite um numero :"))

def tabuada (numero):
    for i in range (1,11):
            print(f'{numero} * {i} = {numero*i}')

tabuada(numero)
            
        
     
    
